#define _IOC_NRBITS      8
#define _IOC_TYPEBITS    8
#define _IOC_SIZEBITS   13	/* Actually 14, see below. */
#define _IOC_DIRBITS     3

#define _IOC_NRMASK      ((1 << _IOC_NRBITS)-1)
#define _IOC_TYPEMASK    ((1 << _IOC_TYPEBITS)-1)
#define _IOC_SIZEMASK    ((1 << _IOC_SIZEBITS)-1)
#define _IOC_XSIZEMASK   ((1 << (_IOC_SIZEBITS+1))-1)
#define _IOC_DIRMASK     ((1 << _IOC_DIRBITS)-1)

#define _IOC_NRSHIFT     0
#define _IOC_TYPESHIFT   (_IOC_NRSHIFT + _IOC_NRBITS)
#define _IOC_SIZESHIFT   (_IOC_TYPESHIFT + _IOC_TYPEBITS)
#define _IOC_DIRSHIFT    (_IOC_SIZESHIFT + _IOC_SIZEBITS)

#define _IOC_NONE        1U
#define _IOC_READ        2U
#define _IOC_WRITE       4U

#define _IOC(dir,type,nr,size) \
        (((dir)  << _IOC_DIRSHIFT) | \
         ((type) << _IOC_TYPESHIFT) | \
         ((nr)   << _IOC_NRSHIFT) | \
         ((size) << _IOC_SIZESHIFT))

#define _IO(type,nr)        _IOC(_IOC_NONE,(type),(nr),0)
#define _IOR(type,nr,size)  _IOC(_IOC_READ,(type),(nr),sizeof(size))
#define _IOW(type,nr,size)  _IOC(_IOC_WRITE,(type),(nr),sizeof(size))
#define _IOWR(type,nr,size) _IOC(_IOC_READ|_IOC_WRITE,(type),(nr),sizeof(size))

/* Used to decode ioctl numbers in drivers despite the leading underscore... */
#define _IOC_DIR(nr)    \
 ( (((((nr) >> _IOC_DIRSHIFT) & _IOC_DIRMASK) & (_IOC_WRITE|_IOC_READ)) != 0)?   \
                            (((nr) >> _IOC_DIRSHIFT) & (_IOC_WRITE|_IOC_READ)):  \
                            (((nr) >> _IOC_DIRSHIFT) & _IOC_DIRMASK) )
#define _IOC_TYPE(nr)       (((nr) >> _IOC_TYPESHIFT) & _IOC_TYPEMASK)
#define _IOC_NR(nr)         (((nr) >> _IOC_NRSHIFT) & _IOC_NRMASK)
#define _IOC_SIZE(nr)   \
 ((((((nr) >> _IOC_DIRSHIFT) & _IOC_DIRMASK) & (_IOC_WRITE|_IOC_READ)) == 0)?    \
                         0: (((nr) >> _IOC_SIZESHIFT) & _IOC_XSIZEMASK))

/* ...and for the PCMCIA... */

#define IOC_IN          (_IOC_WRITE << _IOC_DIRSHIFT)
#define IOC_OUT         (_IOC_READ << _IOC_DIRSHIFT)
#define IOC_INOUT       ((_IOC_WRITE|_IOC_READ) << _IOC_DIRSHIFT)
#define IOCSIZE_MASK    (_IOC_XSIZEMASK << _IOC_SIZESHIFT)
#define IOCSIZE_SHIFT   (_IOC_SIZESHIFT)

/* Big T */
#define TCGETA		_IOR('T', 1, struct termio)
#define TCSETA		_IOW('T', 2, struct termio)
#define TCSETAW		_IOW('T', 3, struct termio)
#define TCSETAF		_IOW('T', 4, struct termio)
#define TCSBRK		_IO('T', 5)
#define TCXONC		_IO('T', 6)
#define TCFLSH		_IO('T', 7)
#define TCGETS		_IOR('T', 8, struct termios)
#define TCSETS		_IOW('T', 9, struct termios)
#define TCSETSW		_IOW('T', 10, struct termios)
#define TCSETSF		_IOW('T', 11, struct termios)

/* Note that all the ioctls that are not available in Linux have a 
 * double underscore on the front to: a) avoid some programs to
 * thing we support some ioctls under Linux (autoconfiguration stuff)
 */
/* Little t */
#define TIOCGETD	_IOR('t', 0, int)
#define TIOCSETD	_IOW('t', 1, int)
#define __TIOCHPCL        _IO('t', 2) /* SunOS Specific */
#define __TIOCMODG        _IOR('t', 3, int) /* SunOS Specific */
#define __TIOCMODS        _IOW('t', 4, int) /* SunOS Specific */
#define __TIOCGETP        _IOR('t', 8, struct sgttyb) /* SunOS Specific */
#define __TIOCSETP        _IOW('t', 9, struct sgttyb) /* SunOS Specific */
#define __TIOCSETN        _IOW('t', 10, struct sgttyb) /* SunOS Specific */
#define TIOCEXCL	_IO('t', 13)
#define TIOCNXCL	_IO('t', 14)
#define __TIOCFLUSH       _IOW('t', 16, int) /* SunOS Specific */
#define __TIOCSETC        _IOW('t', 17, struct tchars) /* SunOS Specific */
#define __TIOCGETC        _IOR('t', 18, struct tchars) /* SunOS Specific */
#define __TIOCTCNTL       _IOW('t', 32, int) /* SunOS Specific */
#define __TIOCSIGNAL      _IOW('t', 33, int) /* SunOS Specific */
#define __TIOCSETX        _IOW('t', 34, int) /* SunOS Specific */
#define __TIOCGETX        _IOR('t', 35, int) /* SunOS Specific */
#define TIOCCONS	_IO('t', 36)
#define __TIOCSSIZE     _IOW('t', 37, struct sunos_ttysize) /* SunOS Specific */
#define __TIOCGSIZE     _IOR('t', 38, struct sunos_ttysize) /* SunOS Specific */
#define TIOCGSOFTCAR	_IOR('t', 100, int)
#define TIOCSSOFTCAR	_IOW('t', 101, int)
#define __TIOCUCNTL       _IOW('t', 102, int) /* SunOS Specific */
#define TIOCSWINSZ	_IOW('t', 103, struct winsize)
#define TIOCGWINSZ	_IOR('t', 104, struct winsize)
#define __TIOCREMOTE      _IOW('t', 105, int) /* SunOS Specific */
#define TIOCMGET	_IOR('t', 106, int)
#define TIOCMBIC	_IOW('t', 107, int)
#define TIOCMBIS	_IOW('t', 108, int)
#define TIOCMSET	_IOW('t', 109, int)
#define __TIOCSTART       _IO('t', 110) /* SunOS Specific */
#define __TIOCSTOP        _IO('t', 111) /* SunOS Specific */
#define TIOCPKT		_IOW('t', 112, int)
#define TIOCNOTTY	_IO('t', 113)
#define TIOCSTI		_IOW('t', 114, char)
#define TIOCOUTQ	_IOR('t', 115, int)
#define __TIOCGLTC        _IOR('t', 116, struct ltchars) /* SunOS Specific */
#define __TIOCSLTC        _IOW('t', 117, struct ltchars) /* SunOS Specific */
/* 118 is the non-posix setpgrp tty ioctl */
/* 119 is the non-posix getpgrp tty ioctl */
#define __TIOCCDTR        _IO('t', 120) /* SunOS Specific */
#define __TIOCSDTR        _IO('t', 121) /* SunOS Specific */
#define TIOCCBRK        _IO('t', 122)
#define TIOCSBRK        _IO('t', 123)
#define __TIOCLGET        _IOW('t', 124, int) /* SunOS Specific */
#define __TIOCLSET        _IOW('t', 125, int) /* SunOS Specific */
#define __TIOCLBIC        _IOW('t', 126, int) /* SunOS Specific */
#define __TIOCLBIS        _IOW('t', 127, int) /* SunOS Specific */
#define __TIOCISPACE      _IOR('t', 128, int) /* SunOS Specific */
#define __TIOCISIZE       _IOR('t', 129, int) /* SunOS Specific */
#define TIOCSPGRP	_IOW('t', 130, int)
#define TIOCGPGRP	_IOR('t', 131, int)
#define TIOCSCTTY	_IO('t', 132)
#define TIOCGSID	_IOR('t', 133, int)
/* Get minor device of a pty master's FD -- Solaris equiv is ISPTM */
#define TIOCGPTN	_IOR('t', 134, unsigned int) /* Get Pty Number */
#define TIOCSPTLCK	_IOW('t', 135, int) /* Lock/unlock PTY */

/* Little f */
#define FIOCLEX		_IO('f', 1)
#define FIONCLEX	_IO('f', 2)
#define FIOASYNC	_IOW('f', 125, int)
#define FIONBIO		_IOW('f', 126, int)
#define FIONREAD	_IOR('f', 127, int)
#define TIOCINQ		FIONREAD
#define FIOQSIZE	_IOR('f', 128, loff_t)

/* SCARY Rutgers local SunOS kernel hackery, perhaps I will support it
 * someday.  This is completely bogus, I know...
 */
#define __TCGETSTAT       _IO('T', 200) /* Rutgers specific */
#define __TCSETSTAT       _IO('T', 201) /* Rutgers specific */

/* Linux specific, no SunOS equivalent. */
#define TIOCLINUX	0x541C
#define TIOCGSERIAL	0x541E
#define TIOCSSERIAL	0x541F
#define TCSBRKP		0x5425
#define TIOCTTYGSTRUCT	0x5426
#define TIOCSERCONFIG	0x5453
#define TIOCSERGWILD	0x5454
#define TIOCSERSWILD	0x5455
#define TIOCGLCKTRMIOS	0x5456
#define TIOCSLCKTRMIOS	0x5457
#define TIOCSERGSTRUCT	0x5458 /* For debugging only */
#define TIOCSERGETLSR   0x5459 /* Get line status register */
#define TIOCSERGETMULTI 0x545A /* Get multiport config  */
#define TIOCSERSETMULTI 0x545B /* Set multiport config */
#define TIOCMIWAIT	0x545C /* Wait input */
#define TIOCGICOUNT	0x545D /* Read serial port inline interrupt counts */

/* Used for packet mode */
#define TIOCPKT_DATA		 0
#define TIOCPKT_FLUSHREAD	 1
#define TIOCPKT_FLUSHWRITE	 2
#define TIOCPKT_STOP		 4
#define TIOCPKT_START		 8
#define TIOCPKT_NOSTOP		16
#define TIOCPKT_DOSTOP		32

/* Socket-level I/O control calls. */
#define FIOSETOWN 	0x8901
#define SIOCSPGRP	0x8902
#define FIOGETOWN	0x8903
#define SIOCGPGRP	0x8904
#define SIOCATMARK	0x8905
#define SIOCGSTAMP	0x8906		/* Get stamp */

